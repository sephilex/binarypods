#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "MultiProgressView.h"

FOUNDATION_EXPORT double MultiProgressViewVersionNumber;
FOUNDATION_EXPORT const unsigned char MultiProgressViewVersionString[];

