//
//  MultiProgressView.h
//  MultiProgressView
//
//  Created by Mac Gallagher on 3/26/19.
//  Copyright © 2019 Mac Gallagher. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MultiProgressView.
FOUNDATION_EXPORT double MultiProgressViewVersionNumber;

//! Project version string for MultiProgressView.
FOUNDATION_EXPORT const unsigned char MultiProgressViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MultiProgressView/PublicHeader.h>


