//
//  DynamicBlurView.h
//  DynamicBlurView
//
//  Created by Kyohei Ito on 2015/04/08.
//  Copyright (c) 2015年 kyohei_ito. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamicBlurView.
FOUNDATION_EXPORT double DynamicBlurViewVersionNumber;

//! Project version string for DynamicBlurView.
FOUNDATION_EXPORT const unsigned char DynamicBlurViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicBlurView/PublicHeader.h>


