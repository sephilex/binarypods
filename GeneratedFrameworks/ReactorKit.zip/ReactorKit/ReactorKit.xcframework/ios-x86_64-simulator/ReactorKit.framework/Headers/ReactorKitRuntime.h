#import <Foundation/Foundation.h>

//! Project version number for ReactorKit.
FOUNDATION_EXPORT double ReactorKitVersionNumber;

//! Project version string for ReactorKit.
FOUNDATION_EXPORT const unsigned char ReactorKitVersionString[];
